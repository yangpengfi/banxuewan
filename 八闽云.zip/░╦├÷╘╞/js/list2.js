var menuType = 0;
var menuData;

function getData() {
    if (menuType == 0) { //主播带你游福建
        menuData = { name: "主播带你游福建", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 1) {
        menuData = { name: "空中看福建", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "好戏剧", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "好电视剧", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "好电影", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "八闽先贤", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "文化名家", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "民俗艺人", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "红色文化", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "船政文化", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "海丝文化", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "朱子文化", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "闽台文化", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    } else if (menuType == 2) {
        menuData = { name: "文化遗产", titleIcon: "title_huikan.png", id: "MANU0000000000168796" };
    }

}
