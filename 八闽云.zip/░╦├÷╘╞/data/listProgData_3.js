// JavaScript Document
{
    "selectableItemList": [
        {
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img11.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img12.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img10.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},		
		
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img9.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img8.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img7.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img6.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		},
{
            "assetId": "OTHE1000000000219836",
            "chargeMode": "1",
            "childFolderSortDirection": 0,
            "childFolderSortby": "",
            "createDate": "",
            "titleFull": "测试数据4",
			"runtime":"01:30:00",
            "folderAssetId": "",
            "folderDetails": {
                "actorsDisplay": "袁立,郭晓,李静,赵瑞,赵玲",
                "area": "中国内地",
                "director": [
                    {
                        "name": "张进"
                    }
                ],
                "favorRating": "0",
                "producter": [
                    
                ],
                "publishDate": "",
                "recommandRating": 0,
                "recommandTimes": 0,
                "selectableItemCount": 20,
                "selectionChoice": [
                    
                ],
                "summarMedium": "",
                "summarvShort": "",
                "videoType": "0"
            },
            "folderShowType": "",
            "folderType": "2",
            "imageList": [
                {
                    "height": 543,
                    "posterUrl": "poster_root/20150730/OTHE1000000000219836/410x543/20150730153229404_0011.jpg",
                    "rank": 1,
                    "width": 410
                },
                {
                    "height": 246,
                    "posterUrl": "p2_img5.jpg",
                    "rank": 1,
                    "width": 178
                }
            ],
            "infoText": "1973年，某部队信连里，班长韩琳、新兵姜士安、张雁南在一起学习生活。出身贫苦的农村兵姜士安在生活上受到了韩琳细致入微的关心，这使他渐渐喜欢上了韩琳。张雁南也在韩琳的帮助下不断的提高着自己的能力而韩琳在努力学习、刻苦工作的同时对英俊潇洒的军宣队队员彭湛渐生好感",
            "linkUrl": "",
            "modifyDate": "",
            "parentAssetId": "MANU0000000000051140",
            "previewAssetld": "",
            "previewProviderld": "",
            "providerId": "GZCTV",
            "secondDisplayName": "",
            "selectableItemSortDirection": 0,
            "selectableItemSortby":"",
            "selectionChoice": [
							{
								"audioType":"",
								"displayPrice":"",
								"format":"",
								"languageSet":null,
								"rentalPeriod":"0",
								"screenShape":"",
								"viewLimit":"0"
							}
							],
			"serviceCode":"",
			"serviceId":"100800000005",
			"viewLevel":"0"
		}
		],
"orderFields":[],
"restartAtToken":"11",
"totalResults":38
}
